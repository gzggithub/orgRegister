'use strict'
module.exports = {
  NODE_ENV: '"production"'
  // API_HOST:'https://newapi.taoerxue.cn' //，生产环境下使用接口地址
}
